PREMIUM COLLECTION BY SANJIDA — MULTI-IMAGE PRODUCT VERSION

SETUP
1. Extract the ZIP.
2. Open the extracted folder in Terminal / Command Prompt.
3. Run: npm install
4. Run: npm start
5. Open: http://localhost:3000
6. Admin: http://localhost:3000/admin.html

PRODUCT IMAGE UPLOAD
- Admin now supports up to 6 images per product.
- Select 1–6 images in the Product Images field.
- The first selected image is the main image.
- Images are automatically resized/compressed in the browser before saving.
- Each product keeps its own gallery.
- 3 Piece, 4 Piece, 2 Piece, Skin Care, Hair Care, Baby Products, Jewellery, Bags and Electronic Gadgets all use the same system.
- On each collection page, customers can click the small thumbnails to switch the main product image.

IMPORTANT
The image gallery is stored inside data/products.json as compressed data URLs, so no extra upload package is required. The server JSON limit is set to 30 MB for product uploads.
