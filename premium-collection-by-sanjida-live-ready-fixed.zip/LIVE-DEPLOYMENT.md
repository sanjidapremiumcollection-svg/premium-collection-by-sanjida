# Premium Collection By Sanjida — Live Ready

This is the complete Node.js/Express project.

## Local
```bash
npm install
npm start
```
Open `http://localhost:3000`.
Admin: `http://localhost:3000/admin`

## Domain + hosting
Use a Node.js-capable host. Set the start command to `npm start` and use the host-provided `PORT`. After deployment, add your domain in the host dashboard and set DNS records exactly as the host instructs. Enable HTTPS/SSL.

The app stores products and orders in `data/products.json` and `data/orders.json`, so the hosting environment must provide persistent writable storage if you want those files to survive redeploys/restarts. For production, use a persistent volume or move product/order storage to a database.

## Contact buttons
WhatsApp: https://wa.me/8801719529751
Facebook Page: https://www.facebook.com/PremiumcollectionbySanjida
