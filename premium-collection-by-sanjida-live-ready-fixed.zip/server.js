const express = require("express");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const publicDir = path.join(__dirname, "public");
const dataDir = path.join(__dirname, "data");
const productsFile = path.join(dataDir, "products.json");
const ordersFile = path.join(dataDir, "orders.json");

fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(ordersFile)) fs.writeFileSync(ordersFile, "[]", "utf8");

const ADMIN = {
  number: "01918444462",
  username: "sanjidacollection",
  password: "5566"
};
const sessions = new Map();

app.use(express.json({ limit: "35mb" }));
app.use(express.static(publicDir));
app.get("/health", (req,res)=>res.json({ok:true,service:"premium-collection-by-sanjida"}));

function readJson(file, fallback=[]) {
  try { return JSON.parse(fs.readFileSync(file, "utf8")); } catch { return fallback; }
}
function writeJson(file, value) {
  fs.writeFileSync(file, JSON.stringify(value, null, 2), "utf8");
}
function readProducts(){ return readJson(productsFile, []); }
function writeProducts(v){ writeJson(productsFile, v); }
function readOrders(){ return readJson(ordersFile, []); }
function writeOrders(v){ writeJson(ordersFile, v); }

function normalizeImages(body, group) {
  let images = Array.isArray(body.images) ? body.images.filter(Boolean).slice(0, 6) : [];
  if (!images.length && body.image) images = [body.image];
  if (!images.length) images = [group === "clothing" ? "/assets/clothing/2-piece.jpg" : "/assets/skin-care.jpg"];
  return images;
}
function requireAdmin(req,res,next){
  const auth = req.headers.authorization || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
  if (!token || !sessions.has(token)) return res.status(401).json({ok:false,message:"Admin login required."});
  req.adminToken = token;
  next();
}

/* The requested admin URL: http://localhost:3000/admin */
app.get("/admin", (req,res)=>res.sendFile(path.join(publicDir,"admin-login.html")));
app.get("/admin/", (req,res)=>res.sendFile(path.join(publicDir,"admin-login.html")));
app.get("/admin/dashboard", (req,res)=>res.sendFile(path.join(publicDir,"admin-dashboard.html")));

app.post("/api/admin/login", (req,res)=>{
  const {number,username,password}=req.body||{};
  if(number===ADMIN.number && username===ADMIN.username && password===ADMIN.password){
    const token=crypto.randomBytes(32).toString("hex");
    sessions.set(token,{createdAt:Date.now()});
    return res.json({ok:true,token});
  }
  res.status(401).json({ok:false,message:"Phone number, username or password is incorrect."});
});
app.post("/api/admin/logout", requireAdmin, (req,res)=>{
  sessions.delete(req.adminToken);
  res.json({ok:true});
});
app.get("/api/admin/me", requireAdmin, (req,res)=>res.json({ok:true}));

app.get("/api/products",(req,res)=>res.json(readProducts()));

app.post("/api/products", requireAdmin, (req,res)=>{
  const body=req.body||{};
  const group=body.group==="cosmetics"?"cosmetics":"clothing";
  const images=normalizeImages(body,group);
  const product={
    id:"pcs-"+Date.now()+"-"+Math.random().toString(36).slice(2,7),
    name:String(body.name||"Untitled Product"),
    price:Number(body.price||0),
    group,
    subcategory:String(body.subcategory||(group==="clothing"?"2-piece":"skin-care")),
    images,
    image:images[0],
    description:String(body.description||""),
    active:body.active!==false
  };
  const products=readProducts();
  products.unshift(product);
  writeProducts(products);
  res.json({ok:true,product});
});

app.put("/api/products/:id", requireAdmin, (req,res)=>{
  const products=readProducts();
  const i=products.findIndex(p=>p.id===req.params.id);
  if(i<0)return res.status(404).json({ok:false,message:"Product not found."});
  const old=products[i], body=req.body||{};
  const group=body.group==="cosmetics"?"cosmetics":(old.group||"clothing");
  const images=normalizeImages({...old,...body},group);
  products[i]={...old,...body,id:old.id,group,price:Number(body.price??old.price??0),images,image:images[0],active:body.active!==false};
  writeProducts(products);
  res.json({ok:true,product:products[i]});
});
app.delete("/api/products/:id", requireAdmin,(req,res)=>{
  const products=readProducts().filter(p=>p.id!==req.params.id);
  writeProducts(products);res.json({ok:true});
});

app.post("/api/orders",(req,res)=>{
  const body=req.body||{};
  const id="PCS-"+Date.now().toString().slice(-8);
  const order={orderId:id,status:"Pending",placedAt:new Date().toISOString(),...body};
  const orders=readOrders();orders.unshift(order);writeOrders(orders);
  res.json({ok:true,orderId:id,message:"Order placed successfully."});
});
app.get("/api/admin/orders",requireAdmin,(req,res)=>res.json({ok:true,orders:readOrders()}));
app.patch("/api/admin/orders/:id",requireAdmin,(req,res)=>{
  const orders=readOrders();const i=orders.findIndex(o=>o.orderId===req.params.id);
  if(i<0)return res.status(404).json({ok:false,message:"Order not found."});
  orders[i]={...orders[i],status:req.body.status||orders[i].status};writeOrders(orders);res.json({ok:true,order:orders[i]});
});
app.delete("/api/admin/orders/:id",requireAdmin,(req,res)=>{
  writeOrders(readOrders().filter(o=>o.orderId!==req.params.id));res.json({ok:true});
});

app.listen(PORT,()=>console.log(`Premium Collection By Sanjida running at http://localhost:${PORT}`));
