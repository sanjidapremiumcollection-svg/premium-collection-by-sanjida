@echo off
title Premium Collection By Sanjida
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
  echo Node.js is not installed.
  echo Please install Node.js from https://nodejs.org/
  pause
  exit /b 1
)
if not exist node_modules (
  echo Installing required files for the first run...
  call npm install
)
start "" "http://localhost:3000"
node server.js
