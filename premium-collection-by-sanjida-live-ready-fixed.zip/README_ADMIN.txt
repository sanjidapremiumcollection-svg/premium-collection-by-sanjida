PREMIUM COLLECTION BY SANJIDA — ADMIN
======================================

Run:
  npm install
  npm start

Customer website:
  http://localhost:3000

Admin:
  http://localhost:3000/admin

Login:
  Phone number: 01918444462
  Username: sanjidacollection
  Password: 5566

Admin is a separate professional page. Products added from the dashboard are
saved to data/products.json and immediately appear on the customer storefront.
Customer checkout orders are saved to data/orders.json and appear under Admin > Orders.

If an older server is running, stop it first and restart with npm start.
